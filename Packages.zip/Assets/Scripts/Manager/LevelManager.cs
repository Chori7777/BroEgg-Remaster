using UnityEngine;
using System.Collections.Generic;
using ED262C;
using UnityEngine.UI;

[DefaultExecutionOrder(-100)]
public class LevelManager : MonoBehaviour
{
    //  SINGLETON 
    private static LevelManager instance;
    public static LevelManager Instance => instance;

    // DATOS EDITABLES EN EL INSPECTOR 
    public List<WaveData> waveList = new List<WaveData>();

    [Header("M�sica")]
    public bool changeMusic;   // �esta wave cambia la m�sica?
    public SoundID music;      // cu�l suena


    [Header("UI de Victoria")]
    [SerializeField] private GameObject victoryPanel;
    public GameObject VictoryPanel => victoryPanel;


    //  COLA
    private ISimpleQueue<WaveData> waveQueue = new SimpleArrayQueue<WaveData>();

    private WaveData currentWave;
    public Image shopPanel;
    public Button[] botones;
    public ObjectsInventory inventory;
    public ShopManager shopManager;
    [SerializeField] private GameObject inventoryPanel;
    private int pauseChangedFrame = -1;

    public GameObject InventoryPanel => inventoryPanel;
    public bool IsPaused => levelStateMachine != null && levelStateMachine.IsPaused;
    public bool ControlsBlocked => IsPaused || Time.timeScale == 0f || pauseChangedFrame == Time.frameCount;

    public LevelStateMachine levelStateMachine;

    public EnemySpawnerManager enemySpawnerManager;


    public WaveData CurrentWave => currentWave;

    private float timeRemaining;
    public float TimeRemaining
    {
        get => timeRemaining;
        set => timeRemaining = value;
    }

    private int currentRound;

    public int CurrentRound => currentRound;

    

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        if (inventoryPanel != null) inventoryPanel.SetActive(false);
        

        // Cargamos todas las waves del Inspector a la cola, en orden
        for (int i = 0; i < waveList.Count; i++)
        {
            waveQueue.Enqueue(waveList[i]);
        }

        levelStateMachine = new LevelStateMachine(this);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            ToggleInventory();
            return;
        }
        levelStateMachine.UpdateMachine();
    }

    public void ToggleInventory()
    {
        if (levelStateMachine == null || inventoryPanel == null) return;
        if (IsPaused)
            levelStateMachine.Resume();
        else
        {
            // No superponer el inventario con la pausa existente de Escape.
            if (Time.timeScale == 0f && levelStateMachine.CurrentState != levelStateMachine.Shop) return;
            levelStateMachine.Pause();
        }
        pauseChangedFrame = Time.frameCount;
    }

    private void OnDestroy()
    {
        if (instance != this) return;
        if (IsPaused) levelStateMachine.Resume();
        instance = null;
    }

    public void AdvanceToNextWave()
    {
        currentWave = waveQueue.Dequeue();
        currentRound++;
    }
    private void PlayLastMusicUpTo(int waveIndex)
    {
        if (AudioManager.Instance == null) return;

        // Busca hacia atr�s la �ltima wave que tenga m�sica definida
        for (int i = Mathf.Min(waveIndex, waveList.Count - 1); i >= 0; i--)
        {
            if (waveList[i].music != SoundID.None)
            {
                AudioManager.Instance.PlayMusic(waveList[i].music);
                return;
            }
        }
    }
    public bool HasMoreWaves()
    {
        // Compara el round actual con el total de waves configuradas en el Inspector
        return currentRound < waveList.Count;
    }
    public void RestoreToRound(int round)
    {
        waveQueue.Clear();
        for (int i = round - 1; i < waveList.Count; i++)
            waveQueue.Enqueue(waveList[i]);
        currentRound = round - 1;

        PlayLastMusicUpTo(round - 1); // m�sica correcta al reintentar
        levelStateMachine.ChangeState(levelStateMachine.Gameplay);
    }

    public void ChangeTime(float time)
    {
        Time.timeScale = time;
    }



    public void NextWave()
    {
        if (IsPaused) return;
        shopPanel.gameObject.SetActive(false);
        levelStateMachine.ChangeState(levelStateMachine.Gameplay);
    }

    public void CheckRoundProgression()
    {
        if (waveQueue.Count == 0)
        {
            // No hay m�s oleadas en la cola: Victoria
            levelStateMachine.ChangeState(levelStateMachine.Victory);
        }
        else
        {
            // Todav�a hay contenido: Avanzar a la tienda
            AdvanceToNextWave();
            shopPanel.gameObject.SetActive(true);
            levelStateMachine.ChangeState(levelStateMachine.Shop);
        }
    }
}
