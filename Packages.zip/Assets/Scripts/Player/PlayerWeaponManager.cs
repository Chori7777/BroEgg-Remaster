using System;
using Unity.VisualScripting;
using UnityEngine;
using static WeaponData;

public class PlayerWeaponManager : MonoBehaviour
{
    [SerializeField] GameObject hand;
    public GameObject Hand => hand;
    public FactoryWeapon factoryWeapon;
    public InventaryWeapons inventoryManager;

    void Start()
    {
        GiveWeapon("Pistol");
    }   

    public WeaponController GiveWeapon(string weaponId) //ehora este metodo devuelve un arma, cosa que siempre tuvo que haber sido asi
    {
        WeaponController newWeapon = factoryWeapon.CreateWeapon(weaponId, hand.transform.position);

        Transform weaponTransform = newWeapon.getTransform();
        weaponTransform.SetParent(hand.transform);
        weaponTransform.localPosition = Vector3.zero;
        weaponTransform.localRotation = Quaternion.identity;

        inventoryManager.AddWeapon(newWeapon);
        return newWeapon;
    }
    public bool RemoveWeapon(WeaponController weapon)
    {
       return inventoryManager.RemoveWeapon(weapon);
    }
    void Update()
    {
        if (LevelManager.Instance != null && LevelManager.Instance.ControlsBlocked) return;
        IWeapon currentWeapon = inventoryManager.CurrentWeapon();
        if (currentWeapon == null) Debug.Log("No tengo arma");

        
        bool isTriggering = false;

        if (currentWeapon != null)
        {
            switch(currentWeapon.GetShootingType())
            {
                case ShootingType.Automatic:

                    // Autom�tica
                    isTriggering = Input.GetMouseButton(0);
                    break;

                case ShootingType.Single:

                    // Semiautom�tica
                    isTriggering = Input.GetMouseButtonDown(0);
                    break;

                case ShootingType.Shotgun:

                    // Escopeta
                    isTriggering = Input.GetMouseButtonDown(0);

                    break;

                default:
                    isTriggering = false;
                    break;
            }
        }
            

        if (isTriggering)
        {
            currentWeapon.shoot();

        }
    }
    // Chequeamos si esta el arma, el inventoryManager se encarga de eso buscando el id q le damos desde el ButtonLogic
    public bool HasWeapon(string weaponId)
    {
        return inventoryManager.HasWeapon(weaponId);
    }
}