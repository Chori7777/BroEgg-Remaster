using UnityEngine;

public class Walk : IState
{
    PlayerMovement player;


    Rigidbody2D rb;

    Vector2 direction;

    public Walk(PlayerMovement player)
    {
        this.player = player;
    }
    public void Enter()
    {
        player.Animator.CrossFade("Walk", 0.05f);
    }

    public void Exit()
    {

    }

    public void UpdateState()
    {

        direction = new Vector2(player.x, player.y).normalized;

        player.Rb.linearVelocity = direction * player.PlayerStats.Speed; //lo tuve que cambiar a linear velocity nico, perdon, pero addforce no funciona con moveposition

        if (player.x == 0 && player.y == 0) 
        {
            player.statemachine.ChangeState(player.IdleState);
        }

        if(Input.GetKey(KeyCode.Space))
        {
            if(player.DashCooldown >= 2)
            {
                player.statemachine.ChangeState(player.DashState);
                player.DashCooldown = 0;
            }
        }
    }
}
