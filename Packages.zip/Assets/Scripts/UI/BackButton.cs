using UnityEngine;
using UnityEngine.UI;
public class BackButton : MonoBehaviour
{
    private void Awake()
    {
        // Le asignamos el listener al bot�n autom�ticamente por c�digo
        Button btn = GetComponent<Button>();
        btn.onClick.AddListener(OnBackClicked);
    }

    private void OnBackClicked()
    {
        if (UIManager.Instance != null)
        {
            UIManager.Instance.GoBack();
            Time.timeScale = 1f;
        }
        else
        {
            Debug.LogWarning("[BackButton] No se encontr� el UIManager.Instance en la escena papu.");
        }
    }
}
