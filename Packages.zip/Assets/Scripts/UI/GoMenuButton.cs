using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class GoMenuButton : MonoBehaviour
{
    private void Awake()
    {
        // Le asignamos el listener al bot�n autom�ticamente por c�digo
        Button btn = GetComponent<Button>();
        btn.onClick.AddListener(OnGoMenuClicked);
    }

    private void OnGoMenuClicked()
    {
        if (UIManager.Instance != null)
        {
            UIManager.Instance.ClearToRoot();
            Time.timeScale = 1f;
            UnityEngine.Cursor.visible = true;
            SceneManager.LoadScene("Main Menu");
        }
        else
        {
            Debug.LogWarning("[BackButton] No se encontr� el UIManager.Instance en la escena papu.");
        }
    }
}
