using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] float defaultBulletSpeed;
    Rigidbody2D rb;
    public BulletPool pool; //publica para acceder desde las weapons
    Collider2D bulletCollider;
    [SerializeField] float timer = 3f;
    private int damage;

    public float Speed => defaultBulletSpeed;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        bulletCollider = GetComponent<Collider2D>();
    }

    void Update()
    {
        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            pool.Recycle(this);
            timer = 3;
        }
    }

    public void Setup(Vector2 direction, int damage, Collider2D ownerCollider)
    {
        //guardamos el parametro de damage en la variable de instancia para usarlo en OnTriggerEnter2D y poder hacer da�o!
        this.damage = damage;
        rb.linearVelocity = direction * defaultBulletSpeed;
        if (ownerCollider != null)
        {
            Physics2D.IgnoreCollision(bulletCollider, ownerCollider);
        }
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player")) return;


        IDamageable damageable = collision.GetComponent<IDamageable>();

        if (damageable != null)
        {
            damageable.TakeDamage(damage);

            pool.Recycle(this);
            timer = 3;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject)
        {
            pool.Recycle(this);
            timer = 3;
        }
    }
}
